<head>
  <style>
    p {
      color: green;
    }
  </style>
</head>
