selector {
  property: value;
  property: value;
}
