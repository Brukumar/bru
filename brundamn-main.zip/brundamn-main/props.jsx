<ChildComponent name="John" />
