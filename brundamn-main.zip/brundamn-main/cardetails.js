import React from 'react';

function CarDetails() {
  return (
    <div className="car-details">
      <h1>Car Details</h1>
      <p>Details about the selected car will go here.</p>
    </div>
  );
}

export default CarDetails;
